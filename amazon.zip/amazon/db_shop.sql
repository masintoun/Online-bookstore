-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 05, 2022 at 02:05 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminUser` varchar(255) NOT NULL,
  `adminPass` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminName`, `adminUser`, `adminPass`) VALUES
(3, 'prasat', 'admin', '25f9e794323b453885f5181f1b624d0b'),
(4, 'test', 'admin1', '25f9e794323b453885f5181f1b624d0b'),
(6, 'masintoun', 'masintoun', '25f9e794323b453885f5181f1b624d0b'),
(7, 'eal khemra', 'mckhemra', '25f9e794323b453885f5181f1b624d0b'),
(8, 'Nib', 'nib@gmail.com', '25f9e794323b453885f5181f1b624d0b'),
(9, 'National Institute of Business', 'nib', '25f9e794323b453885f5181f1b624d0b'),
(10, 'Hello', 'hello', '25f9e794323b453885f5181f1b624d0b');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `brandId` int(11) NOT NULL,
  `brandName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`brandId`, `brandName`) VALUES
(4, 'Robert Kiyosaki'),
(8, ' Eric Ries'),
(9, ' Yuval Noah Harari'),
(10, ' Jordan B. Peterson'),
(11, ' Sally Helgesen'),
(12, ' David J Schwartz'),
(13, ' Simon Sinek'),
(14, ' James Clear'),
(15, ' Rhonda Byrne'),
(16, ' Robert Greene'),
(18, ' Thomas J. Stanley'),
(19, ' Paul McCartney'),
(20, ' Alan Lightman'),
(24, ' Suzanne Collins');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cartId` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `catId` int(11) NOT NULL,
  `catName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catId`, `catName`) VALUES
(12, ' Entrepreneurship'),
(13, ' Drama'),
(14, ' Adventure'),
(15, ' Fantasy'),
(16, ' Historical Fiction'),
(17, ' Horror'),
(18, ' Science Fiction (Sci-Fi)'),
(19, ' Cookbooks'),
(20, ' Self-Help'),
(22, ' Non-Fiction'),
(23, ' Finance'),
(24, 'Business'),
(25, ' Biography'),
(26, ' Children\'s literature'),
(31, 'Novel');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_compare`
--

CREATE TABLE `tbl_compare` (
  `compareId` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_compare`
--

INSERT INTO `tbl_compare` (`compareId`, `cmrId`, `productId`, `productName`, `price`, `image`) VALUES
(38, 9, 38, 'Mastery', 10.00, 'uploads/0a69ebe599.jpg'),
(39, 9, 23, 'Retire Young Retire Rich', 10.00, 'uploads/65116a2164.jpg'),
(49, 13, 50, 'The Hunger Games', 11.00, 'uploads/23fa733c8f.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(255) NOT NULL,
  `c_address` text NOT NULL,
  `c_city` varchar(30) NOT NULL,
  `c_district` varchar(30) DEFAULT NULL,
  `c_sangkat` varchar(30) DEFAULT NULL,
  `c_phone` varchar(30) NOT NULL,
  `c_email` varchar(255) NOT NULL,
  `c_pass` varchar(32) NOT NULL,
  `c_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`c_id`, `c_name`, `c_address`, `c_city`, `c_district`, `c_sangkat`, `c_phone`, `c_email`, `c_pass`, `c_status`) VALUES
(8, 'sintoun12', '168, Chbar ampov', 'Phnom Penh', 'Toul Kork', 'Nirot', '0967165369', 'sintoun12@gmail.com', '25f9e794323b453885f5181f1b624d0b', 1),
(9, 'sintoun14', '168, Chbar ampov', 'Phnom Penh', 'Toul Kok', 'dfadafd', '0967165369', 'sintoun14@gmail.com', '25f9e794323b453885f5181f1b624d0b', 1),
(10, 'sintoun15', 'St351, #168', 'Phnom Penh', 'Chbar Ampov', 'Niroth', '0967165369', 'sintoun15@gmail.com', '25f9e794323b453885f5181f1b624d0b', 1),
(11, 'eal khemra', '#723 E0E1 Kampuchea Krom Bdv. (1.91 mi) Phnom Penh, Cambodia, 12156', 'Phnom Penh', '7 Makara', 'Nirot', '081356261', 'ealkhemra@gmail.com', 'a88d6dbaf322a72c2ecb39fec6066d89', 1),
(12, 'Nib', 'St3, #891', 'Select City', 'Chamkarmon', 'Meanchey3', '067453478', 'nib@gmail.com', '25f9e794323b453885f5181f1b624d0b', 1),
(13, 'Soksan', 'St2, #323', 'Phnom Penh', 'Meanchey', 'Meanchey ler', '012345678', 'soksan@gmail.com', '25f9e794323b453885f5181f1b624d0b', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `orderId` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`orderId`, `cmrId`, `productId`, `productName`, `quantity`, `price`, `image`, `date`, `status`) VALUES
(66, 10, 34, 'The Power', 1, 10.00, 'uploads/36a4289b3a.jpg', '2021-12-29 10:24:54', 1),
(67, 9, 41, 'The Millionaire Mind', 1, 10.00, 'uploads/6e31490a6f.jpg', '2021-12-29 11:22:00', 1),
(68, 9, 23, 'Retire Young Retire Rich', 1, 10.00, 'uploads/65116a2164.jpg', '2021-12-29 11:22:29', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `body` text NOT NULL,
  `price` float(5,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `productName`, `catId`, `brandId`, `body`, `price`, `image`, `keywords`, `type`) VALUES
(13, 'Who Took My Money?', 12, 7, '<p><span>Reveals how to actually speed up and maximize the return on investments to achieve total financial independence.</span></p>', 10.00, 'uploads/4277f76e0d.jpg', 'Who Took My Money', 1),
(14, 'The Lean Startup', 12, 8, '<p><span>Most startups fail. But many of those failures are preventable.&nbsp;<em>The Lean Startup&nbsp;</em>is a new approach being adopted across the globe, changing the way companies are built and new products are launched.<br /></span><br /><span>Eric Ries defines a startup as&nbsp;an organization dedicated to creating something new under conditions of extreme uncertainty. This is just as true for one person in a garage or a group of seasoned professionals in a Fortune 500 boardroom. What they have in common is a mission to penetrate that fog of uncertainty to discover a successful path to a sustainable business.</span><br /><br /><em>The Lean Startup</em><span>&nbsp;approach fosters companies that are both more capital efficient and that leverage human creativity more effectively. Inspired by lessons from lean manufacturing, it relies on &ldquo;validated learning,&rdquo; rapid scientific experimentation, as well as a number of counter-intuitive practices that shorten product development cycles, measure actual progress without resorting to vanity metrics, and learn what customers really want. It enables a company to shift directions with agility, altering plans inch by inch, minute by minute.</span><br /><br /><span>Rather than wasting time creating elaborate business plans,&nbsp;</span><em>The Lean Startup</em><span>&nbsp;offers entrepreneurs&mdash;in companies of all sizes&mdash;a way to test their vision continuously, to adapt and adjust before it&rsquo;s too late. Ries provides a scientific approach to creating and managing successful startups in a age when companies need to innovate more than ever.</span></p>', 24.00, 'uploads/0a542ffe31.png', 'Eric Ries,Startup,Entrepreneurship,Business,non-fiction', 3),
(18, 'Sapiens: A Brief History of Humankind', 8, 9, '<p><span>Is there anything more dangerous than dissatisfied and irresponsible gods who don&rsquo;t know what they want? Planet Earth is 4.5 billion years old. In just a fraction of that time, one species among countless others has conquered it. Us. We are the most advanced and most destructive animals ever to have lived. What makes us brilliant? What makes us deadly? What makes us Sapiens? In this bold and provocative book, Yuval Noah Harari explores who we are, how we got here and where we\'re going. Sapiens is a thrilling account of humankind\'s extraordinary history - from the Stone Age to the Silicon Age - and our journey from insignificant apes to rulers of the world. A specialist in World History, military history and medieval history, Yuval Noah Harari is best known for his investigations into macro-historical questions concerning the relationship between history and science, the origins of mankind and its future. Amongst his publications are the bestselling books Sapiens and Homo Deus.</span></p>', 10.00, 'uploads/b8a7a2089a.jpg', 'Sapiens: A Brief History of Humankind', 2),
(19, '12 Rules for Life : An Antidote to Chaos', 22, 10, '<p><span>The #1 Sunday Times bestseller from \'the most influential public intellectual in the Western world right now\' (New York Times) - now in paperback. How should we live properly in a world of chaos and uncertainty? Jordan Peterson has helped millions of people, young and old, men and women, aim at a life of responsibility and meaning. Now he can help you. Drawing on his own work as a clinical psychologist and on lessons from humanity\'s oldest myths and stories, Peterson offers twelve profound and realistic principles to live by. After all, as he reminds us, we each have a vital role to play in the unfolding destiny of the world. Deep, rewarding and enlightening, 12 Rules for Life is a lifeboat built solidly for stormy seas: ancient wisdom applied to our contemporary problems.</span></p>', 10.00, 'uploads/32474e3b0f.jpg', '12 Rules for Life : An Antidote to Chaos', 2),
(20, 'How Women Rise', 22, 11, '<p><span>Do you hesitate about putting forward ideas? Are you reluctant to claim credit for your achievements? Do you find it difficult to get the support you need from your boss or the recognition you deserve from your colleagues? If your answer to any of these is `Yes\', How Women Rise will help get you back on track. Inspiring and practical by turns, it identifies 12 common habits that can prove an obstacle to future success and tells you how to overcome them. In the process, it points the way to a career that will satisfy your ambitions and help you make the difference you want to make in the world.</span></p>', 10.00, 'uploads/1534a1698a.jpg', 'How Women Rise', 1),
(21, 'The Magic of Thinking Big', 22, 12, '<p><span>Your go-to guide to a better life, starting with the way you think Join 6 million readers around the world who have capitalised on the power of now First published in 1959, David J Schwartz\'s classic teachings are as powerful today as they were then. Practical, empowering and hugely engaging, this book shows that the key to success is the way you think. Not only will this timeless classic inspire you, it will give you the tools to change your life for the better - starting right now. Schwartz\'s step-by-step approach will show you how to: - Defeat disbelief and the negative power it creates - Make your mind produce positive thoughts - Plan a concrete success-building programme - Do more and do it better by turning on your creative power - Capitalise on the power of NOW Updated for the 21st century, The Magic of Thinking Big will guide you to high achievement in every area of your life.</span></p>', 10.00, 'uploads/97dd869876.jpg', 'The Magic of Thinking Big', 2),
(22, 'Rich Dad Poor Dad', 23, 4, '<p><span>Rich Dad Poor Dad is a 1997 book written by Robert Kiyosaki and Sharon Lechter. It advocates the importance of financial literacy, financial independence and building wealth through investing in assets, real estate investing, starting and owning businesses, as well as increasing one\'s financial intelligence.</span></p>', 10.00, 'uploads/b04272ebdb.jpg', 'rich dad poor dad', 3),
(23, 'Retire Young Retire Rich', 23, 4, '<p><span>If you don\'t plan on working hard all your life... this book is for you. If you\'re ready to retire (or want to retire early enoughto enjoy your retirement years) you can learn from Robert\'s story of how he and his wife Kim started with nothing and \'retired\'&mdash;financially free&mdash;in less than 10 years. This book makes the case for how a context shift in the way we think about money and investing allows us to see opportunities others miss and create the life you deserve.</span></p>', 10.00, 'uploads/65116a2164.jpg', 'Retire Young Retire Rich', 2),
(24, 'The Business of the 21st Century', 23, 4, '<p><span>In The Business of the 21st Century, Robert Kiyosaki explains the revolutionary business of network marketing in the context of what makes any business a success in any economic situation. This book lends credibility to multilevel marketing business, and justifies why it is an ideal avenue through which to learn basic business and sales skills... and earn money.</span></p>', 10.00, 'uploads/b2e967f915.jpg', 'The Business of the 21st Century', 1),
(26, 'Rich Kid, Smart Kid', 23, 4, '<p><span>RICH KID SMART KID is written for parents who value education, want to give their child a financial and academic head start in life, and are willing to take an active role to make it happen. In the Information Age, a good education is more important than ever. But the current educational system may not be providing all the information your child needs. This book was designed to fill in the gaps: to help you give your child the same inspiring and practical financial knowledge that Robert Kiyosaki\'s rich dad gave him.</span></p>', 10.00, 'uploads/3dd7901f75.jpg', 'Rich Kid, Smart Kid', 3),
(27, 'Start With Why', 20, 13, '<p><span>The inspirational bestseller that ignited a movement and asked us to find our WHY</span><br /><br /><span>Discover the book that is captivating millions on TikTok and that served as the basis for one of the most popular TED Talks of all time&mdash;with more than 56 million views and counting. Over a decade ago, Simon Sinek started a movement that inspired millions to demand purpose at work, to ask what was the WHY of their&nbsp;organization.&nbsp;Since then, millions have been touched by the power of his ideas, and these ideas remain as relevant and timely as ever.</span><br /><span>&nbsp;</span><br /><span>START WITH WHY&nbsp;asks (and answers)&nbsp;the questions: why are some people and organizations more innovative, more influential, and more profitable than others? Why do some command greater loyalty from customers and employees alike? Even among the successful, why are so few able to repeat their success over and over?</span><br /><span>&nbsp;</span><br /><span>People like Martin Luther King Jr., Steve Jobs, and the Wright Brothers had little in common, but they all started with WHY. They realized that people won\'t truly buy into a product, service, movement, or idea until they understand the WHY behind it.&nbsp;</span><br /><span>&nbsp;</span><br /><span>START WITH WHY shows that the leaders who have had the greatest influence in the world all think, act and communicate the same way&mdash;and it\'s the opposite of what everyone else does. Sinek calls this powerful idea The Golden Circle, and it provides a framework upon which organizations can be built, movements can be led, and people can be inspired. And it all starts with WHY.</span></p>', 10.00, 'uploads/cf4bbb890c.png', 'Start With Why', 3),
(28, 'Leaders Eat Last ', 12, 13, '<p>Imagine a world where almost everyone wakes up inspired to go to work, feels trusted and valued during the day, then returns home feeling fulfilled. This is not a crazy, idealized notion. Today, in many successful organizations, great leaders create environments in which people naturally work together to do remarkable things.</p>\r\n<p>In his work with organizations around the world, Simon Sinek noticed that some teams trust each other so deeply that they would literally put their lives on the line for each other. Other teams, no matter what incentives are offered, are doomed to infighting, fragmentation and failure. Why?</p>\r\n<p>The answer became clear during a conversation with a Marine Corps general. \"Officers eat last,\" he said. Sinek watched as the most junior Marines ate first while the most senior Marines took their place at the back of the line. What\'s symbolic in the chow hall is deadly serious on the battlefield: Great leaders sacrifice their own comfort--even their own survival--for the good of those in their care.</p>\r\n<p>Too many workplaces are driven by cynicism, paranoia, and self-interest. But the best ones foster trust and cooperation because their leaders build what Sinek calls a \"Circle of Safety\" that separates the security inside the team from the challenges outside.</p>\r\n<p>Sinek illustrates his ideas with fascinating true stories that range from the military to big business, from government to investment banking.</p>', 10.00, 'uploads/f0c3e6c665.png', 'Leaders Eat Last ', 2),
(29, 'Find Your Why', 20, 13, '<p><span>I&nbsp;believe&nbsp;fulfillment is a&nbsp;right and not a&nbsp;privilege. We are all entitled to wake up in the morning inspired to go to work,&nbsp;feel safe when we&rsquo;re there and return home fulfilled at the end of the day.&nbsp;Achieving that fulfillment starts with understanding exactly&nbsp;WHY&nbsp;we do what we do.&nbsp;</span><br /><span>&nbsp;</span><br /><span>As&nbsp;</span><em>Start With Why</em><span>&nbsp;has spread around the world, countless&nbsp;readers have asked me the&nbsp;same&nbsp;question: How&nbsp;can I apply&nbsp;</span><em>Start With Why</em><span>&nbsp;to&nbsp;my&nbsp;career, team,&nbsp;company&nbsp;or nonprofit? Along with two of my colleagues, Peter Docker and David Mead, I created&nbsp;this&nbsp;hands-on, step-by-step guide&nbsp;to&nbsp;help you find&nbsp;your WHY.</span><br /><br /><span>With detailed&nbsp;exercises, illustrations, and&nbsp;action steps for&nbsp;every stage&nbsp;of the process,&nbsp;</span><em>Find Your Why</em><span>&nbsp;can help you address many important concerns, including:</span><br /><span>&nbsp;</span><br /><span>* What if my WHY sounds&nbsp;just&nbsp;like my competitor&rsquo;s?</span><br /><span>* Can&nbsp;I&nbsp;have more than one WHY?</span><br /><span>* If my work doesn&rsquo;t match my WHY, what&nbsp;should&nbsp;I do?</span><br /><span>* What if my team can&rsquo;t agree on our WHY?</span><br /><span>&nbsp;</span><br /><span>Whether you\'ve just started your first job, are leading a team, or are CEO of your own company, the exercises in this book will&nbsp;help&nbsp;guide&nbsp;you on a path to long-term success&nbsp;and fulfillment, for&nbsp;both you and your colleagues.&nbsp;</span><br /><span>&nbsp;</span><br /><span>Thank you for joining&nbsp;us as we work together to&nbsp;build a world in which more people&nbsp;start with WHY.</span></p>', 10.00, 'uploads/4b963a2b90.png', 'Find Your Why', 3),
(30, 'The Infinite Game', 24, 13, '<p><span>How do we win a game that has no end? Finite games, like football or chess, have known players, fixed rules and a clear endpoint. The winners and losers are easily identified. Infinite games, games with no finish line, like business or politics, or life itself, have players who come and go. The rules of an infinite game are changeable while infinite games have no defined endpoint. There are no winners or losers&mdash;only ahead and behind.</span><br /><br /><span>The question is, how do we play to succeed in the game we&rsquo;re in?</span><br /><br /><span>In this revelatory new book, Simon Sinek offers a framework for leading with an infinite mindset. On one hand, none of us can resist the fleeting thrills of a promotion earned or a tournament won, yet these rewards fade quickly. In pursuit of a Just Cause, we will commit to a vision of a future world so appealing that we will build it week after week, month after month, year after year. Although we do not know the exact form this world will take, working toward it gives our work and our life meaning.</span><br /><br /><span>Leaders who embrace an infinite mindset build stronger, more innovative, more inspiring organizations. Ultimately, they are the ones who lead us into the future.</span></p>', 10.00, 'uploads/0ffd3bbeca.png', 'The Infinite Game', 1),
(31, 'Atomic Habits', 20, 14, '<p><span>No matter your goals,&nbsp;</span><em>Atomic Habits</em><span>&nbsp;offers a proven framework for improving--every day. James Clear, one of the world\'s leading experts on habit formation, reveals practical strategies that will teach you exactly how to form good habits, break bad ones, and master the tiny behaviors that lead to remarkable results.</span><br /><br /><span>If you\'re having trouble changing your habits, the problem isn\'t you. The problem is your system. Bad habits repeat themselves again and again not because you don\'t want to change, but because you have the wrong system for change. You do not rise to the level of your goals. You fall to the level of your systems. Here, you\'ll get a proven system that can take you to new heights.</span><br /><br /><span>Clear is known for his ability to distill complex topics into simple behaviors that can be easily applied to daily life and work. Here, he draws on the most proven ideas from biology, psychology, and neuroscience to create an easy-to-understand guide for making good habits inevitable and bad habits impossible. Along the way, readers will be inspired and entertained with true stories from Olympic gold medalists, award-winning artists, business leaders, life-saving physicians, and star comedians who have used the science of small habits to master their craft and vault to the top of their field.</span><br /><br /><span>Learn how to:</span><br /><span>&nbsp;&nbsp;</span><span>&bull;</span><span>&nbsp;&nbsp;make time for new habits (even when life gets crazy);</span><br /><span>&nbsp;&nbsp;</span><span>&bull;</span><span>&nbsp;&nbsp;overcome a lack of motivation and willpower;</span><br /><span>&nbsp;&nbsp;</span><span>&bull;</span><span>&nbsp;&nbsp;design your environment to make success easier;</span><br /><span>&nbsp;&nbsp;</span><span>&bull;</span><span>&nbsp;&nbsp;get back on track when you fall off course;</span><br /><span>...and much more.</span><br /><br /><em>Atomic Habits</em><span>&nbsp;will reshape the way you think about progress and success, and give you the tools and strategies you need to transform your habits--whether you are a team looking to win a championship, an organization hoping to redefine an industry, or simply an individual who wishes to quit smoking, lose weight, reduce stress, or achieve any other goal.</span></p>', 10.00, 'uploads/9d2d6b5061.jpg', 'Atomic Habits', 1),
(32, 'The Secret', 20, 15, '<p><span>In 2006, a groundbreaking feature-length film revealed the great mystery of the universe&mdash;</span><em>The Secret&mdash;</em><span>and, later that year, Rhonda Byrne followed with a book that became a worldwide bestseller.</span><br /><br /><span>Fragments of a Great Secret have been found in the oral traditions, in literature, in religions, and philosophies throughout the centuries. For the first time, all the pieces of The Secret come together in an incredible revelation that will be life-transforming for all who experience it.</span><br /><br /><span>In this book, you&rsquo;ll learn how to use The Secret in every aspect of your life&mdash;money, health, relationships, happiness, and in every interaction you have in the world. You&rsquo;ll begin to understand the hidden, untapped power that&rsquo;s within you, and this revelation can bring joy to every aspect of your life.</span><br /><br /><em>The Secret</em><span>&nbsp;contains wisdom from modern-day teachers&mdash;men and women who have used it to achieve health, wealth, and happiness. By applying the knowledge of The Secret, they bring to light compelling stories of eradicating disease, acquiring massive wealth, overcoming obstacles, and achieving what many would regard as impossible.</span></p>', 10.00, 'uploads/ed3d3bd189.jpg', 'The Secret', 1),
(33, 'The Magic', 20, 15, '<p><span>One word changes everything...No matter who you are or where you are, no matter what your current circumstances,&nbsp;<em>The Magic</em>&nbsp;is going to change your entire life!</span><br /><br /><span>For more than twenty centuries, words within a sacred text have mystified, confused, and been misunderstood by almost all who read them. Only a very few people through history have realized that the words are a riddle, and that once you solve the riddle&mdash;once you uncover the mystery&mdash;a new world will appear before your eyes.</span><br /><br /><span>In&nbsp;</span><em>The Magic</em><span>, Rhonda Byrne reveals this life-changing knowledge to the world. Then, on an incredible 28-day journey, she teaches you how to apply this knowledge in your everyday life.</span></p>', 10.00, 'uploads/45828e1c2d.jpg', 'The Magic', 3),
(34, 'The Power', 20, 15, '<p><span>The Secret&nbsp;revealed the law of attraction. Now Rhonda Byrne reveals the greatest power in the universe&mdash;<em>The Power&nbsp;</em>to have anything you want.</span><br /><br /><span>In this book you will come to understand that all it takes is just one thing to change your relationships, money, health, happiness, career, and your entire life. Every discovery, invention, and human creation comes from The Power. Perfect health, incredible relationships, a career you love, a life filled with happiness, and the money you need to be, do, and have everything you want, all come from The Power. The life of your dreams has always been closer to you than you realized, because The Power&mdash;to have everything good in your life&mdash;is inside you. To create anything, to change anything, all it takes is just one thing&hellip;THE POWER.</span></p>', 10.00, 'uploads/36a4289b3a.jpg', 'The Power', 2),
(35, 'The Greatest Secret', 20, 15, '<p>Ancient traditions knew that to hide a secret it should be put in plain sight, where no-one will think to look for it.&nbsp;Billions of people on our planet have searched&mdash;but few have discovered the truth. Those few are completely free from negativity and live in permanent peace and happiness.</p>\r\n<p>For the rest of us, whether we realize it or not, we&rsquo;ve been in search of this truth unceasingly every single day of our lives.&nbsp;What secret can possibly be so lifechanging? What single discovery offers a direct path to end suffering and to live a life of deep joy?</p>\r\n<p><span>&nbsp;</span></p>\r\n<p><em>The Greatest Secret</em>&nbsp;is a quantum leap that will take the reader beyond the material world and into the spiritual realm, where all possibilities exist. Inside<em>&nbsp;The Greatest Secret,&nbsp;</em>you&rsquo;ll find:</p>\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>Profound wisdom</span>&nbsp;from spiritual teachers from around the world, past and present, who have discovered the greatest secret.</p>\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>Healing practices</span>&nbsp;that&nbsp;can be put to use immediately to dissolve fears, uncertainty, anxiety, and pain.</p>\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>The ultimate key&nbsp;</span>to end suffering and discover lasting happiness.</p>\r\n<p>&nbsp;</p>\r\n<p>&ldquo;<em>The Secret</em>&nbsp;showed you how to create anything you want to be, do, or have. Nothing has changed - it is as true today as it ever was. This book reveals the greatest discovery a human being can ever make, and shows you the way out of negativity, problems, and what you don&rsquo;t want, to a life of permanent happiness and bliss.&rdquo;<span>&mdash;From&nbsp;<em>The Greatest Secret</em></span></p>', 10.00, 'uploads/9643ae8a1b.jpg', 'The Greatest Secret', 1),
(36, 'The 48 Laws of Power ', 20, 16, '<p><span>In the book that&nbsp;</span><em>People&nbsp;</em><span>magazine proclaimed &ldquo;beguiling&rdquo; and &ldquo;fascinating,&rdquo; Robert Greene and Joost Elffers have distilled three thousand years of the history of power into 48 essential laws by drawing from the philosophies of Machiavelli, Sun Tzu, and Carl Von Clausewitz and also from the lives of figures ranging from Henry Kissinger to P.T. Barnum.</span><br /><span>&nbsp;</span><br /><span>Some laws teach the need for prudence (&ldquo;Law 1: Never Outshine the Master&rdquo;), others teach the value of confidence (&ldquo;Law 28: Enter Action with Boldness&rdquo;), and many recommend absolute self-preservation (&ldquo;Law 15: Crush Your Enemy Totally&rdquo;). Every law, though, has one thing in common: an interest in total domination. In a bold and arresting two-color package,&nbsp;</span><em>The 48 Laws of Power&nbsp;</em><span>is ideal whether your aim is conquest, self-defense, or simply to understand the rules of the game.</span></p>', 10.00, 'uploads/c8686f9ce7.jpg', 'The 48 Laws of Power ', 1),
(37, 'The Art of Seduction', 20, 16, '<p><span>From the author of the multi-million copy bestseller&nbsp;<em>The 48 Laws of Power&nbsp;</em>and&nbsp;<em>The Laws of Human Nature,&nbsp;</em>a mesmerizing handbook on seduction: the most subtle and effective form of power</span><br /><span>&nbsp;</span><br /><span>When raised to the level of art, seduction, an indirect and subtle form of power, has toppled empires, won elections and enslaved great minds. Immerse yourself in the twenty-four maneuvers and strategies of the seductive process, the ritual by which a seducer gains mastery over his target. Understand how to \"Poeticize Your Presence,\" &ldquo;Keep them in Suspense &ndash; What Comes Next&rdquo; and &ldquo;Master the Art of the Bold Move&rdquo;. Every bit as essential as&nbsp;</span><em>The 48 Laws of Power</em><span>,&nbsp;</span><em>The Art of Seduction</em><span>&nbsp;is an indispensable primer of persuasion that reveals one of history\'s greatest weapons and the ultimate form of power.</span></p>', 10.00, 'uploads/0148d06f70.jpg', 'The Art of Seduction', 1),
(38, 'Mastery', 20, 16, '<p><span>From the bestselling author of&nbsp;<em>The 48 Laws of Power&nbsp;</em>and&nbsp;<em>The Laws of Human Nature,&nbsp;</em>a vital work revealing that the secret to mastery is already within you.<br /><br /></span><span>Each one of us has within us the potential to be a Master. Learn the secrets of the field you have chosen, submit to a rigorous apprenticeship, absorb the hidden knowledge possessed by those with years of experience, surge past competitors to surpass them in brilliance, and explode established patterns from within. Study the behaviors of Albert Einstein, Charles Darwin, Leonardo da Vinci and the nine contemporary Masters interviewed for this book.&nbsp;</span><br /><br /><span>The bestseller author of&nbsp;</span><em>The 48 Laws of Power</em><span>,&nbsp;</span><em>The Art of Seduction</em><span>, and&nbsp;</span><em>The 33 Strategies of War</em><span>,</span><em>&nbsp;</em><span>Robert Greene has spent a lifetime studying the laws of power. Now, he shares the secret path to greatness. With this seminal text as a guide, readers will learn how to unlock the passion within and become masters.</span></p>', 10.00, 'uploads/0a69ebe599.jpg', 'Mastery', 2),
(39, 'The Laws of Human Nature', 20, 16, '<p><span>Robert Greene is a master guide for millions of readers, distilling ancient wisdom and philosophy into essential texts for seekers of power, understanding and mastery. Now he turns to the most important subject of all - understanding people\'s drives and motivations, even when they are unconscious of them themselves.</span><br /><br /><span>We are social animals. Our very lives depend on our relationships with people. Knowing why people do what they do is the most important tool we can possess, without which our other talents can only take us so far. Drawing from the ideas and examples of Pericles, Queen Elizabeth I, Martin Luther King Jr, and many others, Greene teaches us how to detach ourselves from our own emotions and master self-control, how to develop the empathy that leads to insight, how to look behind people\'s masks, and how to resist conformity to develop your singular sense of purpose. Whether at work, in relationships, or in shaping the world around you,&nbsp;</span><em>The Laws of Human Nature</em><span>&nbsp;offers brilliant tactics for success, self-improvement, and self-defense.</span></p>', 10.00, 'uploads/12997e744b.jpg', 'the law of human nature', 1),
(40, 'The Millionaire Next Door', 23, 18, '<p><span>The bestselling</span><span>&nbsp;</span><span>The Millionaire Next Door</span><span>&nbsp;</span><span>identifies seven common traits that show up again and again among those who have accumulated wealth. Most of the truly wealthy in this country don\'t live in Beverly Hills or on Park Avenue-they live next door. This new edition, the first since 1998, includes a new foreword for the twenty-first century by Dr. Thomas J. Stanley.</span></p>', 10.00, 'uploads/8641fb52e0.jpg', 'The Millionaire Next Door', 3),
(41, 'The Millionaire Mind', 23, 18, '<p><span>\"Readers with an entrepreneurial turn of mind will devour&nbsp;</span><em>The Millionaire Mind</em><span>&nbsp;because it provides road maps on how millionaires found their niches.\"After its first publication, Dr. Thomas J. Stanley\'s second best-seller&nbsp;</span><em>The Millionaire Mind</em><span>&nbsp;spent over four months on the New York Times best-seller list, rising to position #2, and has sold over half a million copies. Here is the first paperback edition of Stanley\'s second groundbreaking study of America\'s wealthy.</span><br /><br /><em>The Millionaire Mind</em><span>&nbsp;targets a population of millionaires who have accumulated substantial wealth and live in ways that openly demonstrate their affluence. Exploring the ideas, beliefs, and behaviors that enabled these millionaires to build and maintain their fortunes, Dr. Stanley provides a fascinating look at who America\'s financial elite are and how they got there.</span><br /><br /><span>&emsp;</span><br /><span>*What were their school days like?</span><br /><span>&emsp;</span><br /><span>*How did they respond to negative criticism?</span><br /><span>&emsp;</span><br /><span>*What are the characteristics of the millionaire\'s spouse?</span><br /><span>&emsp;</span><br /><span>*Is religion an important part of their lives?</span><br /><br /><span>The author uncovers the surprising answers to these and similar questions, showing readers through concrete examples just what it is that makes the wealthy prosper when others would turn away dejected or beaten.</span><br /><br /><em>The Millionaire Mind</em><span>&nbsp;promises to be as transformational as Dr. Stanley\'s previous best-seller. This book answers universal questions with solid statistical evidence in an approachable, and anecdotal style. The number of copies sold of this soon-to-be-classic will surely be in the millions.</span></p>', 10.00, 'uploads/6e31490a6f.jpg', 'The Millionaire Mind', 2),
(42, 'Stop Acting Rich', 23, 18, '<p><span>The bestselling author of&nbsp;<em>The Millionaire Next Door</em>&nbsp;reveals easy ways to build real wealth</span></p>\r\n<p>With well over two million of his books sold, and huge praise from many media outlets, Dr. Thomas J. Stanley is a recognized and highly respected authority on how the wealthy act and think. Now, in Stop Acting Rich ? and Start Living Like a Millionaire, he details how the less affluent have fallen into the elite luxury brand trap that keeps them from acquiring wealth and details how to get out of it by emulating the working rich as opposed to the super elite.</p>\r\n<ul>\r\n<li>Puts wealth in perspective and shows you how to live rich without spending more</li>\r\n<li>Details why we spend lavishly and how to stop this destructive cycle</li>\r\n<li>Discusses how being \"rich\" means more than just big houses and luxury cars</li>\r\n</ul>\r\n<p>A defensive strategy for tough times, Stop Acting Rich shows readers how to live a rich, happy life through accumulating more wealth and using it to achieve the type of financial freedom that will create true happiness and fulfillment.</p>', 10.00, 'uploads/4997464d13.jpg', 'Stop Acting Rich', 2),
(43, 'Marketing to the Affluent', 23, 18, '<p><span>The classic in identifying, understanding, and targeting wealthy people, Marketing to the Affluent reveals true demographics, psychographics, and buying and patronage habits of the wealthy and presents the selling techniques of some of the nation\'s top sales and marketing professionals.</span></p>', 10.00, 'uploads/d267de5336.jpg', 'Marketing to the Affluent', 3),
(44, 'The Lyrics', 25, 19, '<p><span>A work of unparalleled candor and splendorous beauty,&nbsp;<em>The Lyrics</em>&nbsp;celebrates the creative life and the musical genius of Paul McCartney through 154 of his most meaningful songs.</span></p>\r\n<p>From his early Liverpool days, through the historic decade of The Beatles, to Wings and his long solo career,&nbsp;<em>The Lyrics</em>&nbsp;pairs the definitive texts of 154 Paul McCartney songs with first-person commentaries on his life and music. Spanning two alphabetically arranged volumes, these commentaries reveal how the songs came to be and the people who inspired them: his devoted parents, Mary and Jim; his songwriting partner, John Lennon; his &ldquo;Golden Earth Girl,&rdquo; Linda Eastman; his wife, Nancy McCartney; and even Queen Elizabeth, among many others. Here are the origins of &ldquo;Let It Be,&rdquo; &ldquo;Lovely Rita,&rdquo; &ldquo;Yesterday,&rdquo; and &ldquo;Mull of Kintyre,&rdquo; as well as McCartney&rsquo;s literary influences, including Shakespeare, Lewis Carroll, and Alan Durband, his high-school English teacher.</p>\r\n<p>With images from McCartney&rsquo;s personal archivesâ€•handwritten texts, paintings, and photographs, hundreds previously unseenâ€•<em>The Lyrics</em>,&nbsp;spanning sixty-four years, becomes the definitive literary and visual record of one of the greatest songwriters of all time.</p>', 10.00, 'uploads/b5f937362b.jpg', 'The Lyrics', 0),
(45, 'Ada and the Galaxies ', 26, 20, '<p><span>Stargazers rejoice! In his first book for children, renowned physicist Alan Lightman and collaborators, with help from the Hubble telescope, light up the night sky.</span><br /><br /><em>New York Times&nbsp;</em><span>best-selling author Alan Lightman, in collaboration with Olga Pastuchiv, brings galaxies close in a stunning picture-book tribute to the interconnectedness of the natural world. Layering photographs taken from the Hubble telescope into charming and expressive art, illustrator Susanna Chapman zooms in on one child&rsquo;s experiences: Ada knows that the best place for star-gazing is on the island in Maine where she vacations with her grandparents. By day, she tracks osprey in the trees, paddles a kayak, and hunts for shells. But she&rsquo;s most in her element when the sun goes down and the stars blink to life. Will the fog this year foil her plans, or will her grandfather find a way to shine a spotlight on the vast puzzle of the universe . . . until the weather turns?</span></p>', 10.00, 'uploads/67629a23d1.jpg', 'Ada and the Galaxies ', 3),
(46, 'It Ends with Us', 26, 20, 'In this â€œbrave and heartbreaking novel that digs its claws into you and doesnâ€™t let go, long after youâ€™ve finished itâ€ (Anna Todd, New York Times bestselling author) from the #1 New York Times ', 10.00, 'uploads/5029d3a59b.jpg', 'It Ends with Us', 3),
(50, 'The Hunger Games', 31, 24, 'Hello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello helloHello hello', 11.00, 'uploads/23fa733c8f.jpg', 'Novel,Suzanne Collins,hello', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rating`
--

CREATE TABLE `tbl_rating` (
  `id` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_rating`
--

INSERT INTO `tbl_rating` (`id`, `cmrId`, `productId`, `rating`) VALUES
(1, 1, 9, 3),
(2, 2, 9, 1),
(3, 4, 9, 5),
(4, 4, 12, 5),
(5, 4, 8, 5),
(6, 4, 4, 5),
(7, 4, 13, 4),
(8, 4, 2, 5),
(9, 4, 3, 5),
(10, 5, 10, 5),
(11, 5, 12, 3),
(12, 5, 13, 4),
(13, 5, 14, 5),
(14, 0, 14, 4),
(15, 4, 14, 5),
(16, 4, 17, 5),
(17, 4, 15, 5),
(18, 5, 17, 4),
(19, 4, 10, 4),
(20, 4, 16, 4),
(21, 9, 45, 4),
(22, 9, 39, 4),
(23, 9, 37, 4),
(24, 9, 36, 4),
(25, 9, 35, 4),
(26, 9, 32, 4),
(27, 9, 31, 4),
(28, 9, 30, 4),
(29, 9, 24, 4),
(30, 9, 42, 4),
(31, 9, 41, 4),
(32, 9, 38, 4),
(33, 9, 34, 4),
(34, 9, 28, 4),
(35, 9, 23, 4),
(36, 9, 21, 4),
(37, 9, 19, 4),
(38, 9, 46, 4),
(39, 9, 43, 4),
(40, 9, 40, 4),
(41, 9, 33, 4),
(42, 9, 29, 4),
(43, 9, 27, 4),
(44, 9, 26, 4),
(45, 11, 26, 5),
(46, 12, 33, 4),
(47, 13, 36, 4),
(48, 13, 50, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wlist`
--

CREATE TABLE `tbl_wlist` (
  `wlistId` int(11) NOT NULL,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(100) NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_wlist`
--

INSERT INTO `tbl_wlist` (`wlistId`, `cmrId`, `productId`, `productName`, `price`, `image`) VALUES
(31, 4, 13, 'Who Took My Money?', 10.00, 'uploads/4277f76e0d.jpg'),
(32, 4, 14, 'The Lean Startup', 24.00, 'uploads/0a542ffe31.png'),
(33, 4, 3, 'Blender Machine', 230.97, 'uploads/f680b4ca87.png'),
(34, 4, 18, 'Sapiens: A Brief History of Humankind', 10.00, 'uploads/b8a7a2089a.jpg'),
(35, 9, 24, 'The Business of the 21st Century', 10.00, 'uploads/b2e967f915.jpg'),
(36, 10, 38, 'Mastery', 10.00, 'uploads/0a69ebe599.jpg'),
(37, 10, 33, 'The Magic', 10.00, 'uploads/45828e1c2d.jpg'),
(38, 9, 38, 'Mastery', 10.00, 'uploads/0a69ebe599.jpg'),
(39, 9, 23, 'Retire Young Retire Rich', 10.00, 'uploads/65116a2164.jpg'),
(40, 11, 26, 'Rich Kid, Smart Kid', 10.00, 'uploads/3dd7901f75.jpg'),
(41, 11, 24, 'The Business of the 21st Century', 10.00, 'uploads/b2e967f915.jpg'),
(42, 12, 35, 'The Greatest Secret', 10.00, 'uploads/9643ae8a1b.jpg'),
(43, 12, 31, 'Atomic Habits', 10.00, 'uploads/9d2d6b5061.jpg'),
(44, 13, 36, 'The 48 Laws of Power ', 10.00, 'uploads/c8686f9ce7.jpg'),
(46, 13, 50, 'The Hunger Games', 11.00, 'uploads/23fa733c8f.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`brandId`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cartId`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_compare`
--
ALTER TABLE `tbl_compare`
  ADD PRIMARY KEY (`compareId`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_wlist`
--
ALTER TABLE `tbl_wlist`
  ADD PRIMARY KEY (`wlistId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `brandId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_compare`
--
ALTER TABLE `tbl_compare`
  MODIFY `compareId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `tbl_wlist`
--
ALTER TABLE `tbl_wlist`
  MODIFY `wlistId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

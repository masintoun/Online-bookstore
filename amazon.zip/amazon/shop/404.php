<?php include 'inc/header.php' ?>

<div class="main">
    <!--    <div class="content">
                            
                <div>
                    
                </div>
                                            
                    
           <div class="clear"></div>
        </div>-->
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 text-center">
                <p style="font-size: 50px; font-weight: bold; color: red">404</p>
                <p class="" style="font-size: 30px;">Not Found !!!</p>
            </div>
        </div>
    </div>
</div>


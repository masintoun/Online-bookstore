<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">

                    <ul class="submenu">
                        <li><a href="inbox.php">Inbox</a></li>
                    </ul>

                    <ul class="submenu">
                        <li><a href="cust_info.php">Customers</a></li>
                    </ul>

                    <ul class="submenu">
                        <li><a href="catadd.php">Add Genre</a> </li>
                        <li><a href="catlist.php">Genre List</a> </li>
                    </ul>

                    <ul class="submenu">
                        <li><a href="brandadd.php">Add Author</a> </li>
                        <li><a href="brandlist.php">Author List</a> </li>
                    </ul>

                    <ul class="submenu">
                        <li><a href="productadd.php">Add Book</a> </li>
                        <li><a href="productlist.php">Book List</a> </li>
                    </ul>

                    <ul class="submenu">
                        <li><a href="../index.php" target="_blank">View Website</a></li>
                    </ul>
            </ul>
        </div>
    </div>
</div>
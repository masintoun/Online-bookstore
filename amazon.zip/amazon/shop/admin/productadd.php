﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/Product.php';?>
<?php include '../classes/Category.php';?>
<?php include '../classes/Brand.php';?>
<?php
    $pd = new Product(); /// obj create
    if(isset($_POST['submit'])){
    
    
    $insertProduct = $pd->productInsert($_POST,$_FILES); /// belong to the product class
    }
?>

<div class="grid_10">
    <div class="box round first grid">
        <h2>Add New Product</h2>
        <div class="block"> 
            <?php
                if(isset($insertProduct)){
                    echo $insertProduct;
                }
            ?>
         <form action="" method="post" enctype="multipart/form-data">
            <table class="form">
               
                <tr>
                    <td>
                        <label>Book Name</label>
                    </td>
                    <td>
                        <input type="text" name="productName" placeholder="Enter Book Name..." class="medium" />
                    </td>
                </tr>
				<tr>
                    <td>
                        <label>Genre</label>
                    </td>
                    <td>
                        <select id="select" name="catId">
                            <option>Select Genre</option>
                            <?php 
                               $cat = new Category();
                               $getCat = $cat->getAllCat();
                               if($getCat){
                                   while ($result = $getCat->fetch_assoc()){
                            ?>
                            <option value="<?php echo $result['catId'] ?>"><?php echo $result['catName']; ?></option>
                               <?php }}?>
                        </select>
                    </td>
                </tr>
				<tr>
                    <td>
                        <label>Author</label>
                    </td>
                    <td>
                        <select id="select" name="brandId">
                            <option>Select Author</option>
                              <?php 
                               $brand = new Brand();
                               $getBrand = $brand->getAllBrand();
                               if($getBrand){
                                   while ($result = $getBrand->fetch_assoc()){
                            ?>
                            <option value="<?php echo $result['brandId'] ?>"><?php echo $result['brandName']; ?></option>
                               <?php }}?>
                        </select>
                    </td>
                </tr>
				
				 <tr>
                    <td style="vertical-align: top; padding-top: 9px;">
                        <label>Description</label>
                    </td>
                    <td>
                        <textarea name="body"></textarea>
                    </td>
                </tr>
	         <tr>
                    <td>
                        <label>Price</label>
                    </td>
                    <td>
                        <input type="text" name="price" placeholder="Enter Price..." class="medium" />
                    </td>
                </tr>
            
                <tr>
                    <td>
                        <label>Upload Image</label>
                    </td>
                    <td>
                        <input type="file" name="image" />
                    </td>
                </tr>
                 <tr>
                    <td>
                        <label>Product Keywords</label>
                    </td>
                    <td>
                        <input type="text" name="keywords" placeholder="Enter Keywords..." class="medium" />
                    </td>
                </tr>
				
		<tr>
                    <td>
                        <label>Product Type</label>
                    </td>
                    <td>
                        <select id="select" name="type">
                            <option>Select Type</option>
                            <option value="1">Best Selling Books</option>
                            <option value="2">New Books</option>
                            <option value="3">Trending Book</option>
                        </select>
                    </td>
                </tr>

				<tr>
                    <td></td>
                    <td>
                        <input style="background-color: #ff7518" type="submit" name="submit" Value="Save" />
                    </td>
                </tr>
            </table>
            </form>
        </div>
    </div>
</div>
<?php include 'inc/footer.php';?>



<?php include '../classes/AdminRegister.php';?>

<?php
    $adm = new Admin(); /// obj create
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['register'])){
       
    $insertAdmin = $adm->adminInsert($_POST); /// belong to the customer class 
    }
    
?>

<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Admin Rigister</title>
<link rel="stylesheet" href="../css/bootstrap.min.css">
<style>
	.form-control:focus {
        border-color: #28a745;
        box-shadow: 0 0 0 2px rgb(240, 119, 37);
    } 
</style>
</head>
<body>
<div class="container" align="center" style="padding-top: 3%">
            <?php
               if(isset($insertAdmin)){
                   echo $insertAdmin;
               }
            ?>
<form action="" method="POST">
	<section id="content">
			<img src="../images/Amazon_Logo.png" alt="" width="15%" height="15%">
            <div>
			    <label class="col-md-4 col-form-label" style="font-weight: bold; font-size:18px">Admin Name</label>
                <div class="col-md-6">
                    <input type="text" placeholder="Name" class="form-control" name="adminName" class="demo border border-light" required autofocus>
                </div>
			</div>
			<div>
			    <label class="col-md-4 col-form-label" style="font-weight: bold; font-size:18px">Admin Username</label>
                <div class="col-md-6">
                    <input type="text" placeholder="Username" class="form-control" name="adminUser" class="demo border border-light" required>
                </div>
			</div>
			<div>
				<label class="col-md-4 col-form-label" style="font-weight: bold; font-size:18px">Password</label>
                	<div class="col-md-6">
                    	<input type="password" class="form-control" name="adminPass" required>
                	</div>
			</div>                      
			<div style="padding: 15px">
                            <input type="submit" name="register" value="Register" class="btn btn-warning" style="width:100px"/>
			</div>
		<div class="button">
            <a href="login.php" style="padding-left: 480px">Login</a>
		</div><!-- button -->
	</section><!-- content -->
</form>
</div><!-- container -->
</body>
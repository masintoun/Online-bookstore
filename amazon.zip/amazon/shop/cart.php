<?php
ob_start();
?>
<?php include 'inc/header.php'; ?>
<?php
if (isset($_GET['delpro'])){
    // product delete from cart
    $delpro    = preg_replace('/[^-a-z-A-Z-0-9_]/', '',$_GET['delpro']);
    $delCartPd = $ct->delCartProduct($delpro);
}?>

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $cartId = $_POST['cartId'];
    $quantity = $_POST['quantity'];
    // update product quantity in cart
    $updateCart = $ct->UpdateCartQuantity($cartId,$quantity);
    // if user enter negative or zero in quantity field
    if($quantity <= 0){
        $delCartPd = $ct->delCartProduct($cartId);
    }
}?>

<?php
// code for reload the page to get the session
if (!isset($_GET['id'])){

    // refresh the page, here we can use other value instead of id,it's not compulsory

    echo "<meta http-equiv='refresh' content='0;URL=?id=live'/>";
}?>

<div class="main">
    <div class="content">
        <div class="cartoption">		
            <div class="cartpage">
                <div class="text-dark" style="font-size: 20px;">Your Cart</div>
                    <?php
                    //cart update msg
                    if(isset($updateCart)){
                        echo $updateCart;
                    }
                    if(isset($delCartPd)){
                        echo $delCartPd;
                    }?>
                <table class="table table-striped">
                    <thead class="bg-dark">
                        <tr class="text-white text-center" style="font-size: 15px;">
                            <th>No</th>
                            <th>Product Name</th>
                            <th>Image</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>                            
                    <tbody class=""> 
                            <?php
                            $getPro = $ct->getCartProduct();
                            // product add in cart using user session id 
                            if($getPro){
                                $i   = 0;
                                $sum = 0;
                                $qty = 0;

                                while($result = $getPro->fetch_assoc()){
                                    $i++;                                    
                                    ?>
                                <tr class="text-center" style=" font-size: 15px;">
                                    <td style="padding-top: 30px"><?php echo $i;?></td>
                                    <td style="padding-top: 30px"><?php echo $result['productName'];?></td>
                                    <td><img src="admin/<?php echo $result['image'];?>" height="90" width="60" alt=""/></td>
                                    <td style="padding-top: 30px"><?php echo '$'.$result['price'];?></td>
                                    <td style="padding-top: 30px">
                                        <form action="" method="post">
                                            <input type="hidden" name="cartId" value="<?php echo $result['cartId']; ?>"/>
                                            <input type="number" name="quantity"  value="<?php echo $result['quantity']; ?>"/>
                                            <input class="btn btn-sm btn-warning" style="border-radius: 10px;" type="submit" name="submit" value="Update"/>
                                        </form>
                                    </td>
                                    <td style="padding-top: 30px "><?php
                                        $total = $result['price'] * $result['quantity'];
                                        echo '$'.$total;
                                        ?></td>
                                    <td style="padding-top: 30px"><a class="text-dark" style="text-decoration: none;" onclick="return confirm('Do you want to remove this book?')"
                                              href="?delpro=<?php echo $result['cartId'];?>">Remove</a></td>
                                </tr>
                                <?php
                                $qty = $qty + $result['quantity'];
                                $sum = $sum + $total;
                                SESSION::set("sum",$sum);
                                SESSION::set("qty",$qty);
                                ?>
                            <?php } }?>                        
                    </tbody>
                </table>
                <?php
                $getdata = $ct->checkCartTable();
                if($getdata){
                    // check the product is exist or not
                    ?>
                    <table style="float:right;text-align:center;font-size: 15px;" width="30%">
                        <tr>
                            <th>Sub Total:</th>
                            <td><?php echo '$'.$sum;?></td>
                        </tr>
                        <tr>
                            <th>Delivery fee:</th>
                            <td>
                                <?php
                                $fee = 2;
                                echo '$'.$fee;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Grand Total:</th>
                            <td>
                                <?php                                
                                $total_sum = $sum + $fee;                                
                                echo '$'.$total_sum;
                                ?>
                            </td>
                        </tr>
                    </table>
                    <?php
                    }else{
                    //echo "<script>location.replace('index.php');</script>";
                    header("Location: index.php");
                    ob_end_flush();
                    }
                ?>                                       
            </div>
            <div class="shopping">
                <div class="shopleft">
                    <a class="btn btn-warning" href="index.php">Continue shopping</a>
                </div>
                <div class="shopright">
                    <a class="btn btn-warning" href="paymentoffline.php">Checkout</a>
                </div>
            </div>
        </div>  	
        <div class="clear"></div>
    </div>
</div>
<?php include 'inc/footer.php' ;



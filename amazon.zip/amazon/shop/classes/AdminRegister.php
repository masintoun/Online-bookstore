<?php
  $filepath = realpath(dirname(__FILE__));
    
    include_once ($filepath.'/../lib/Database.php');
    include_once ($filepath.'/../helpers/Format.php');
?>
<?php
    class Admin {

        //put your code here
        private $db;
        private $fm;
    
        public function __construct() {
    
            $this->db = new Database(); ///obj create
            $this->fm = new Format();   ///obj create
        }

        public function adminInsert($data) {
            $adminName = $this->fm->validation($data['adminName']); /// validation
            $adminUser = $this->fm->validation($data['adminUser']); /// validation
            $adminPass = $this->fm->validation($data['adminPass']); /// validation
    
            $adminName = mysqli_real_escape_string($this->db->link, $data['adminName']);
            $adminUser = mysqli_real_escape_string($this->db->link, $data['adminUser']);
            $adminPass = mysqli_real_escape_string($this->db->link, md5($data['adminPass']));


            $usernamequery = "SELECT * FROM tbl_admin WHERE adminUser = '$adminUser' LIMIT 1";
            $checkusername = $this->db->select($usernamequery);
            if ($checkusername != False){
                echo "<script>alert('Admin username already exists!');</script>";
            }
            else {
                $query = "INSERT INTO tbl_admin(adminName, adminUser, adminPass) VALUES('$adminName', '$adminUser', '$adminPass')";
                $adminsert = $this->db->insert($query);
                if ($adminsert) {

                    echo "<script>alert('Insert successfully!');</script>";
                } else {
                    echo "<script>alert('Email failed!');</script>";
                }
            }
        }
    }
    
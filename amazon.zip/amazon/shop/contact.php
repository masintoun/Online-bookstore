<?php include 'inc/header.php' ?>

    <div align="center">
        <h2 style="margin: 10px;">About Amazon.com</h2>
        <div style="margin-left: 120px; margin-right: 120px">
            <p style="font-family: Verdana, Helvetica, sans-serif;">&emsp;Stephen King once said, "books are a uniquely portable magic". We couldn't agree more. Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus numquam nam dolorem? Recusandae, velit voluptatum ullam eligendi aliquam illo error explicabo a distinctio, iure aliquid quibusdam mollitia iste aspernatur, officia soluta! Beatae harum repellendus debitis tempora iste velit. Qui officiis laboriosam quibusdam dicta, fugiat quam et deleniti aliquam, eaque expedita hic perspiciatis! Labore saepe ut officia? Ullam, tempore provident, voluptas iusto placeat architecto nemo dicta quia nesciunt, consequuntur dolores reiciendis necessitatibus deleniti animi in iure expedita. Sapiente facilis molestias exercitationem suscipit repellat cum nam nihil voluptatibus dignissimos ad repudiandae eum, fugit eligendi tempore ipsa nemo quos.</p>	
            <p style="font-family: Verdana, Helvetica, sans-serif;">&emsp;We're all about combining our love of books with our passion for technology and innovation to create a service unlike any other, with features like cloudmark sync (patent pending) and intelligent restart (patent pending). Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis aliquid reprehenderit ducimus mollitia atque minus dolorum temporibus earum obcaecati culpa debitis consequatur explicabo aspernatur ipsam vitae magni laboriosam nam, voluptas sapiente illo maiores soluta. Iusto, obcaecati, amet dolorum ratione laborum excepturi magnam porro ipsam quia autem facilis mollitia? Nobis dolorem odio officia velit, veniam dolore assumenda iusto voluptas id ea nam qui ab harum earum similique. Sit voluptatum sequi quibusdam modi hic eius neque, eveniet impedit saepe quo? Itaque cumque nemo quisquam qui unde maiores vitae, obcaecati cupiditate tempora rem, laborum quam! Labore qui eum molestiae mollitia sunt, ducimus doloribus.</p>
            <p style="font-family: Verdana, Helvetica, sans-serif;">&emsp;We believe that reading great books makes a person happier, helps them learn, and makes them grow. That's why we've created a book selling service that lets you take your favorite books anywhere. We listen at work, at the gym and on weekend road trips, which makes finding the time to be inspired, educated and entertained by books really easy. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Recusandae, perspiciatis. Porro autem facilis eligendi, unde cum eaque minima repellat, est dolorum non facere assumenda quas doloremque, sit ab. Enim ipsum quibusdam, sed cum exercitationem, voluptatem veniam id officiis cumque quidem earum fugiat quisquam similique maiores! Odit consectetur tenetur ex voluptate eius unde, vitae similique laborum quibusdam! Rem illum aspernatur voluptates quibusdam aliquid eius molestias maxime neque totam quae eligendi et culpa fugiat cumque necessitatibus consequatur repellat sed, dolore expedita laborum vero voluptas similique. Quas eaque ab atque nulla doloremque fuga a. Quo, impedit! Reiciendis, deserunt quasi doloremque impedit repellendus provident.</p>
        </div>
						
        <table>
            <tr>
                <td></td>
                <td  >
					<h2 style="margin-bottom: 20px">Our Developers</h2>
                </td>
            </tr>
            <tr>
                <td>
                    <img src="images/sintoun_1.jpg" width="150px" height="150px" alt="" style="border: solid #ff7518 5px; border-radius: 105px; margin-right: 50px;">
                </td>
                <td>
                    <img src="images/meychin.jpg" width="150px" height="150px" alt="" style="border: solid #ff7518 5px; border-radius: 105px; margin-right: 50px;">
                </td>
                <td>
                    <img src="images/earmchour.jpg" width="150px" height="150px" alt="" style="border: solid #ff7518 5px; border-radius: 105px; margin-right: 50px;">
                </td>
            </tr>
            <tr>
                <td>
                    <div style="margin-left: 10px; margin-top: 10px; font-family: Verdana, Helvetica, sans-serif;">
					Thorng Masintoun
                    </div>
                </td>
                <td>
                    <div style="margin-left: 30px; font-family: Verdana, Helvetica, sans-serif;">
					Lim Meychin
                    </div>
                </td>
                <td>
                    <div style="margin-left: 15px; font-family: Verdana, Helvetica, sans-serif;">
					Seam Eamchour
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <br>
                </td>
            </tr>
            
            <tr>
                <td>
                    <img src="images/khemra.jpg" width="150px" height="150px" alt="" style="border: solid #ff7518 5px; border-radius: 105px; margin-right: 50px;">
                </td>
                <td>
                    <img src="images/bunrong_11.jpg" width="150px" height="150px" alt="" style="border: solid #ff7518 5px; border-radius: 105px; margin-right: 50px;">
                </td>
                <td>
                    <img src="images/mader.jpg" width="150px" height="150px" alt="" style="border: solid #ff7518 5px; border-radius: 105px; margin-right: 50px;">
                </td>
            </tr>
			<br>
            <tr>
                <td>
                    <div style="margin-left: 30px; margin-top:10px; font-family: Verdana, Helvetica, sans-serif;">
					Eal Khemra
                    </div>
                </td>
                <td>
                    <div style="margin-left: 25px; font-family: Verdana, Helvetica, sans-serif;">
					Seb Bunrong
                    </div>
                </td>
                <td>
                    <div style="margin-left: 15px; font-family: Verdana, Helvetica, sans-serif;">
					Thorn Marader
                    </div>
                </td>
            </tr>
        </table>
    </div>   
    <br> <br>

    <div align="center">
        <h2>Contact us</h2>
        <p style="font-family: Verdana, Helvetica, sans-serif;">You can contact to us by checking out our social media:</p>

        <table>
            <tr>
                <td>
                    <a href="https://facebook.com"> 
                        <img width="80px" height="80px "style="border-radius: 50px; margin-right: 25px;" src="images/facebook_1.jpg" alt="facebook">
                    </a>
                </td>
                <td>
                    <a href="https://instagram.com">
                        <img width="80px" height="80px "style="border-radius: 50px; margin-right: 25px;" src="images/instagram.png" alt="instagram">
                    </a>
                </td>
                <td>
                    <a href="https://twitter.com">
                        <img width="80px" height="80px "style="border-radius: 50px; margin-right: 25px;" src="images/twitter.jpg" alt="twitter">
                    </a>
                </td>
                <td>
                    <a href="https://youtube.com">
                        <img width="80px" height="80px "style="border-radius: 50px; margin-right: 25px;" src="images/youtube_1.png" alt="youtube">
                    </a>               
                 </td>
            </tr>
            <tr>
            </tr>
        </table>
		<br>
            <p style="font-family: Verdana, Helvetica, sans-serif">Contact us via email: <a href="gmail.com">amazon@support.com</a></p> 
            <p style="font-family: Verdana, Helvetica, sans-serif">Phone number: +855 123 456 789 / + 855 987 654 321</p>
            <br> <br> <br> <br> <br>
            <p>Amazon.com</p>
    </div>

<?php include 'inc/footer.php' ?>

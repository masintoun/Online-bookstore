<?php include 'inc/header.php';
?>
<?php
$login = Session::get("customerlogin");
if ($login == FALSE) {
    header("Location:login.php");
}
?>
<?php
    $cmrid =  Session::get("customerId"); 
    
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])){
    
    
    $updateCustomer = $cmr->customerUpdate($_POST,$cmrid); /// belong to the customer class
    
    
    }
    
?>
<div class="main">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">

                <?php
                $id = Session::get("customerId");
                // customer id in tbl_customer table 
                $getCustomerData = $cmr->customerData($id);
                if ($getCustomerData) {
                    while ($result = $getCustomerData->fetch_assoc()) {
                        ?>
                
                        <br>
                        <form action="" method="post">
                            
                            <table class="table table-striped table-condensed table-bordered">
                                <thead>
                                    <tr><?php
                                    if(isset($updateCustomer)){
                                        echo $updateCustomer;
                                    }
                                    ?></tr>
                                    <tr class="btn-dark text-center">
                                        <td colspan="2"><span style="font-weight: bold; font-size: 20px;">Update Information</span></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-right"><b>Name :</b></td>
                                        <td><b><input class="form-control" type="text" name="c_name" value="<?php echo $result['c_name']; ?>" /></b></td>

                                    </tr>
                                    <tr>
                                        <td class="text-right"><b>Address :</b></td>
                                        <td><b><input class="form-control" type="text" name="c_address" value="<?php echo $result['c_address']; ?>" /></b></td>

                                    </tr>
                                    <tr>
                                        <td class="text-right"><b>City :</b></td>
                                        <td><b> <select class="form-control" name="c_city">
                                                    <option>Select City</option>
                                                    <option value="Phnom Penh">Phnom Penh</option>
                                                </select></b></td>

                                    </tr> 
                                    <tr>
                                        <td class="text-right"><b>District :</b></td>
                                        <td><b> 
                                                <select class="form-control"  name="c_district">
                                                    <option value="Chamkarmon">Chamkarmon</option>
                                                    <option value="Daun Penh">Daun Penh</option>
                                                    <option value="7 Makara">7 Makara</option>
                                                    <option value="Toul Kork">Toul Kork</option>
                                                    <option value="Dangkor">Dangkor</option>
                                                    <option value="Meanchey">Meanchey</option>
                                                    <option value="Russey Keo">Russey Keo</option>
                                                    <option value="Sen Sok">Sen Sok</option>
                                                    <option value="Por Sen Chey">Por Sen Chey</option>
                                                    <option value="Chroy Changva">Chroy Changva</option>
                                                    <option value="Prek Pnov">Prek Pnov</option>
                                                    <option value="Chbar Ampov">Chbar Ampov</option>
                                                </select></b></td>           
                                    </tr>
                                    <tr>
                                        <td class="text-right"><b>Sangkat :</b></td>
                                        <td><b><input class="form-control" type="text" name="c_sangkat"/></b></td>           
                                    </tr>
                                    <tr>
                                        <td class="text-right"><b>Phone :</b></td>
                                        <td><b><input class="form-control" type="text" name="c_phone" minlength="11" maxlength="11" value="<?php echo $result['c_phone']; ?>" /></b></td>           
                                    </tr>
                                    <tr>
                                        <td class="text-right"><b>Email :</b></td>
                                        <td><b><input class="form-control" type="email" name="c_email" value="<?php echo $result['c_email']; ?>" /></b></td>           
                                    </tr>
                                    <tr>
                                        <td colspan="2">

                                            <input class="form-control btn btn-dark" type="submit" name="submit" value="Save"/>

                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </form>
    <?php }
} ?>                

            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php';
?>



<div class="footer">
   	  <div class="wrapper">	
	     <div class="section group" >
	<!--<div class="section group">-->
		
				<div class="col_1_of_4 span_1_of_4">
						<h4>Get to Know Us</h4>
						<ul>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Customer Service</a></li>
						<li><a href="#">Advanced Search</a></li>
						<li><a href="#">Orders and Returns</a></li>
						<li><a href="#">Contact Us</a></li>
						</ul>
		                </div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Make Money with Us</h4>
						<ul>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Customer Service</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Site Map</a></li>
						<li><a href="#">Search Terms</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Amazon Payment Products</h4>
						<ul>
							<li><a href="#">Sign In</a></li>
							<li><a href="#">View Cart</a></li>
							<li><a href="wishlist.php">My Wishlist</a></li>
							<li><a href="orderdetails.php">My Order</a></li>
							<li><a href="#">Help</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Let Us Help You</h4>
						<ul style="color:white;">
							<li>096 716 536</li>
							<li>011 716 536</li>
						</ul>
				</div>
			</div>
			<div class="copy_right">
				<p>© 1996-2021, Amazon.com, Inc. or its affiliates</p>
		   </div>
     </div>
    </div>
</body>
</html>
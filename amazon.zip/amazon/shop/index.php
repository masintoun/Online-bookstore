<?php include 'inc/header.php' ?>
<?php include 'inc/slider.php' ?>
<head>
</head>
 <div class="main">
    <div class="content">
        <p style="text-align: center;  font-weight: bold; font-size: 20px">Best Selling</p>
        <br>
        <div class="row">
                 <?php
                        $getFpd = $pd->getBestSellingBook();
                        if($getFpd){   
                            while($result = $getFpd->fetch_assoc()){
                  ?>
        <div class="col-md-3">
    <div class="card">
        <a class="text-center" href="details.php?proId=<?php echo $result['productId'];?>"><img class="rounded" src="admin/<?php echo $result['image'] ?>" height="180px" max-width="100%" alt="Card image" style=""/></a>
    <div class="card-body">
        <div class="card-title" style="font-weight: bold; text-align: center;"><?php echo $result['productName'];?></div>
    <div class="card-text">  
            <p style="text-align: center;">$<?php echo $result['price'];?></p></div>
    </div>
       </div>
        </div>
              <?php } } ?>
           
        </div>
		
            <p style="margin-top: 30px; text-align: center;  font-weight: bold; font-size: 20px">New Books</p>
            <br>

        <div class="row">
                 <?php
                        $getFpd = $pd->getNewBook();
                        if($getFpd){   
                            while($result = $getFpd->fetch_assoc()){
                  ?>
        <div class="col-md-3">
    <div class="card">
        <a class="text-center" href="details.php?proId=<?php echo $result['productId'];?>"><img class="rounded" src="admin/<?php echo $result['image'] ?>" height="180px" max-width="100%" alt="Card image" style=""/></a>
    <div class="card-body">
        <div class="card-title" style="font-weight: bold; text-align: center;"><?php echo $result['productName'];?></div>
      <div class="card-text">
        <p style="text-align: center;">$<?php echo $result['price'];?></p></div>
    </div>
       </div>
        </div>
              <?php } } ?>
           
        </div>
 
            <p style="margin-top: 30px; text-align: center;  font-weight: bold; font-size: 20px">Trending Books</p>
            <br>
        <div class="row">
                 <?php
                        $getFpd = $pd->getTrendingBook();
                        if($getFpd){   
                            while($result = $getFpd->fetch_assoc()){
                  ?>
        <div class="col-md-3">
    <div class="card">
        <a class="text-center" href="details.php?proId=<?php echo $result['productId'];?>"><img class="rounded" src="admin/<?php echo $result['image'] ?>" height="180px" max-width="100%" alt="Card image" style=""/></a>
    <div class="card-body">
        <div class="card-title" style="font-weight: bold;  text-align: center;"><?php echo $result['productName'];?></div>
      <div class="card-text">
        <p style="text-align: center;">$<?php echo $result['price'];?></p></div>
    </div>
       </div>
        </div>
              <?php } } ?>
           
        </div>   
        </div>
    </div>
 </div>
<?php include 'inc/footer.php' ;

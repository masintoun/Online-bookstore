<?php ob_start();?>
<?php include 'inc/header.php' ?>
<?php
$login =  Session::get("customerlogin");
if($login==TRUE){
header("Location: orderdetails.php");
ob_end_flush();
}
?>
<?php
    
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['register'])){
       
    $insertCustomer = $cmr->customerInsert($_POST); /// belong to the customer class
        
    }
    
?>
<?php
    
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['login'])){
       
    $loginCustomer = $cmr->customerlogin($_POST); /// belong to the customer class
        
    }
    
?>
<script type="text/javascript">
        
            function getCountry(val) {
                    $.ajax({
                        
                    type: 'POST',
                     url: 'common.php',
                    data: 'cityId='+val,
                    success: function(data){
                            $("#areas").html(data);                 
                        }
                    });
            } 
</script>
<div class="container">
    <div class="row">
        <div class="col-md-4" style="border-right: 2px solid black">
                  <?php
               if(isset($loginCustomer)){
                   echo $loginCustomer;
               }
               ?>
            <form action="" method="post" class="text-center font-weight-bold">  
                
                <p class="text-center font-weight-bold" style="font-size:20px; ">Sign-In to your Amazon account</p>
                <div class="form-group">
                    
                    <input type="email" id="em" class="form-control"  placeholder="Enter email" name="c_email">
                </div>
                <div class="form-group">
                    
                    <input type="password" class="form-control" placeholder="Enter password" name="c_pass">
                </div>
                
                <button type="submit" class="btn btn-dark" name="login">Sign in</button>

            </form>
        </div>
        
        <div class="col-md-8" style="">
            
            <?php
               if(isset($insertCustomer)){
                   echo $insertCustomer;
               }
               ?>
            <form action="" method="post" class="text-center font-weight-bold">
                <p style="font-size:20px; ">Create your Amazon account</p>
                
                <div class="form-row">
                    <div class="form-group col-md-6">

                        <input type="text" class="form-control" name="c_name" placeholder="Name">
                    </div>
                    <div class="form-group col-md-6">

                        <input type="text" class="form-control" name="c_address" placeholder="Street number and House number. Ex: St351, #168)">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">

                        
                        <select class="form-control" name="c_city">
                                <option>Select City</option>
                                <option value="Phnom Penh">Phnom Penh</option>
                            
                                   
                            </select>
                     </div>
                    <div class="form-group col-md-6 ">                        
                        <select class="form-control" id="areas" name="c_district">
                                <option>Select District</option>
                                <option value="Chamkarmon">Chamkarmon</option>
                                <option value="Daun Penh">Daun Penh</option>
                                <option value="7 Makara">7 Makara</option>
                                <option value="Toul Kork">Toul Kork</option>
                                <option value="Dangkor">Dangkor</option>
                                <option value="Meanchey">Meanchey</option>
                                <option value="Russey Keo">Russey Keo</option>
                                <option value="Sen Sok">Sen Sok</option>
                                <option value="Por Sen Chey">Por Sen Chey</option>
                                <option value="Chroy Changva">Chroy Changva</option>
                                <option value="Prek Pnov">Prek Pnov</option>
                                <option value="Chbar Ampov">Chbar Ampov</option>
                        </select>
                    </div>                    
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">

                        <input type="text" class="form-control"name="c_sangkat" placeholder="Sangkat">
                        
                               
                              
                        

                    </div>
                    <div class="form-group col-md-6">

                        <input type="text" class="form-control" minlength="9" maxlength="10" name="c_phone" placeholder="Phone">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">

                        <input type="email" class="form-control" name="c_email" placeholder="Email">
                    </div>
                    <div class="form-group col-md-6">

                        <input type="password" class="form-control" name="c_pass" placeholder="Password">
                    </div>
                </div>


                
                <button type="submit" class="btn btn-dark" name="register">Create Account</button>
            </form>

        </div>

    </div>
    <br>
</div>
<?php include 'inc/footer.php' ?>

<?php
ob_start();
?>
<?php include 'inc/header.php' ;
?>
<?php
$login = Session::get("customerlogin");
if($login==FALSE){
header("Location:login.php");}?>
<?php
// order product of an user
if(isset($_GET['orderid']) && $_GET['orderid']=='order'){
// customer id from tbl_customer table    
$cmrId = Session::get("customerId");
$insertOrder = $ct->orderProduct($cmrId);
$deldata     = $ct->deleteCustomerCart();
header("Location: success.php");
ob_end_flush();
}
?>

<style type="text/css">
    .tbl{
        width : 50%; 
        border: 2px solid black;
        float:right;
    }
    .tbl tr td{
        padding: 3px;
    }
</style>
<br>
    <div class="container">
        <div class="row">
            
            <div class="col-md-6">
            <div class="text-dark" style="font-size: 20px;">Your Payment Details</div>
                    <table class="table table-striped">
                    <thead class="bg-dark">
                        <tr class="text-white text-center" style=" font-size: 15px;">
                            <th>No</th>
                            <th>Product</th>                            
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>                            
                        </tr>
                    </thead>                            
                    <tbody class=""> 
                            <?php
                            $getPro = $ct->getCartProduct();
                            // product add in cart using user session id 
                            if($getPro){
                                $i   = 0;
                                $sum = 0;
                                $qty = 0;

                                while($result = $getPro->fetch_assoc()){
                                    $i++;                                    
                                    ?>
                                <tr class="text-center">
                                    <td style="padding-top: 30px"><?php echo $i;?></td>
                                    <td style="padding-top: 30px"><?php echo $result['productName'];?></td>
                                    <td style="padding-top: 30px"><?php echo '$'.$result['price'];?></td>
                                    <td style="padding-top: 30px"><?php echo $result['quantity'];?></td>
                                    <td style="padding-top: 30px "><?php
                                        $total = $result['price'] * $result['quantity'];
                                        echo '$'.$total;
                                        ?></td>
                                </tr>
                                <?php
                                $qty = $qty + $result['quantity'];
                                $sum = $sum + $total;
                                ?>
                            <?php } }?>                        
                    </tbody>
                </table>
                <table class="tbl table-striped" style=" font-size: 15px;">
                    <tr>
                        <th class="text-right">Sub Total :</th>
                        <td><?php echo '$'.$sum;?></td>
                    </tr>
                    <tr>
                        <th class="text-right">Delivery fee:</th>
                        <td>
                            <?php
                            $fee = 2;
                            echo '$'.$fee;
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th class="text-right">Grand Total:</th>
                        <td>
                            <?php                                
                            $total_sum = $sum + $fee;                                
                            echo '$'.$total_sum;
                            ?>
                        </td>
                    </tr>
                     <tr>
                        <th class="text-right">Quantity:</th>
                        <td><?php echo $qty;?></td>
                    </tr>
                </table>
                
            </div>
            
            
            <div class="col-md-6">
                <?php
                    $id = Session::get("customerId");
                    $getCustomerData = $cmr->customerData($id);
                    if($getCustomerData){
                        while($result = $getCustomerData->fetch_assoc()){                    
                ?>                
            <div class="text-dark" style="font-size: 20px;">My Information Details</div>
            <table class="table table-striped table-condensed table-bordered">
                                    <thead>
                                        <tr class="btn-dark text-center">
                                            <td colspan="2"><span style="font-size: 15px;">Information</span></td>
                                        </tr>
                                    </thead>
                                    <tbody style="font-size: 15px;">
                                        <tr>
                                            <td class="text-right">Name:</td>
                                            <td><?php echo $result['c_name'];?></td>
                                         
                                        </tr>
                                        <tr>
                                            <td class="text-right">Address:</td>
                                            <td><?php echo $result['c_address'];?></td>
                                         
                                        </tr>
                                        <tr>
                                            <td class="text-right">City:</td>
                                            <td><?php echo $result['c_city'];?></td>
           
                                        </tr> 
                                        <tr>
                                            <td class="text-right">District:</td>
                                            <td><?php echo $result['c_district'];?></td>           
                                        </tr>
                                        <tr>
                                            <td class="text-right">Sangkat:</td>
                                            <td><?php echo $result['c_sangkat'];?></td>           
                                        </tr>
                                        <tr>
                                            <td class="text-right">Phone:</td>
                                            <td><?php echo $result['c_phone'];?></td>           
                                        </tr>
                                        <tr>
                                            <td class="text-right">Email:</td>
                                            <td><?php echo $result['c_email'];?></td>           
                                        </tr>
                                        <tr>
                                            <td colspan="2" class="text-right"><a class="btn btn-dark" href="editProfile.php">Update Details</a></td>
                                        </tr>                                          
                                    </tbody>
                    </table>
                    <?php } } ?>
            </div>
            
        </div>
        <div class="text-center">
               <a href="?orderid=order" style="margin-top: 15px;" class="btn btn-warning">Order Now</a> &emsp;
               <a style="margin-top: 15px;color: white; display: inline-block; margin-right: 300px;" class="btn text-dark" onClick="window.open('invoice.php','SearchTip','width=700,height=630,resizable=yes,scrollbars=yes')">Download Invoice</a>
        </div>
        <br>
</div>
<?php include 'inc/footer.php' ;




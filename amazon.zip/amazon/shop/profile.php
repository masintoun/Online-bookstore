<?php include 'inc/header.php' ;
?>
<?php
$login = Session::get("customerlogin");
if($login==FALSE){
header("Location:login.php");}
?>
<div class="main">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
              
                <?php
                    $id = Session::get("customerId");
                    $getCustomerData = $cmr->customerData($id);
                    if($getCustomerData){
                        while ($result = $getCustomerData->fetch_assoc()){
                    
                ?>
                <br>
            <table class="table table-striped table-condensed table-bordered">
                                    <thead>
                                        <tr class="btn-dark text-center">
                                            <td colspan="2"><span style="font-size: 20px;">Information</span></td>
                                        </tr>
                                    </thead>
                                    <tbody style="font-size: 15px;">
                                        <tr>
                                            <td class="text-right">Name:</td>
                                            <td><?php echo $result['c_name'];?></td>
                                         
                                        </tr>
                                        <tr>
                                            <td class="text-right">Address:</td>
                                            <td><?php echo $result['c_address'];?></td>
                                         
                                        </tr>
                                        <tr>
                                            <td class="text-right">City:</td>
                                            <td><?php echo $result['c_city'];?></td>
           
                                        </tr> 
                                          <tr>
                                            <td class="text-right">District:</td>
                                            <td><?php echo $result['c_district'];?></td>           
                                        </tr>
                                        <tr>
                                            <td class="text-right">Sangkat:</td>
                                            <td><?php echo $result['c_sangkat'];?></td>           
                                        </tr>
                                        <tr>
                                            <td class="text-right">Phone:</td>
                                            <td><?php echo $result['c_phone'];?></td>           
                                        </tr>
                                        <tr>
                                            <td class="text-right">Email:</td>
                                            <td><?php echo $result['c_email'];?></td>           
                                        </tr>
                                        <tr>
                                            <td colspan="2" class="text-right"><a class="btn btn-dark" href="editProfile.php">Update Details</a></td>
                                        </tr>
                                          
                                    </tbody>
                                </table>
                    <?php } } ?>
                
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php' ;
?>



<?php
 ob_start();?>
<?php include 'inc/header.php' ;?>
<?php
$login = Session::get("customerlogin");
if($login==FALSE){
header("Location:login.php");
ob_end_flush();
}
?>
<div class="container">
    <br>
    <div class="row">
        <div class="col-md-6 offset-md-3">
                
                <h3 class="text-center text-dark font-weight-bold" style="margin-top: 15px;">Success</h3>

                <div align=center><img  src="images/thank-you-2.gif" alt="Computer man" style="width: 270px;px; height: 270px;"></div>
                
                <hr class="btn-primary">
                <?php
                // customer id from tbl_customer table
                $customerid  = Session::get("customerId"); 
                $amount = $ct->payableAmount($customerid);         
                if($amount){
                       $sum = 0;                     
                        while($result=$amount->fetch_assoc()){
                        $price = $result['price'];
                        $sum   = $sum+$price;
                   }
                ?>               
                <p>Total payment including delivery fee:
                    <?php
                    $fee   = 2;
                    $total = $sum+$fee;
                    echo '$'.$total;}                 
                    ?>
                </p>
                
                <p>Thanks for purchase. Your order successfully. We will delivery your book as soon as possible.</p>  
                </b>
                                     

                <br>
                
        </div>        
    </div>
    <div class="text-center">
                <a href="cart.php" style="margin-top: 10px; margin-right: 30px" class="btn btn-warning">Previous</a>
                <a href="orderdetails.php" style="margin-top: 10pxpx; margin-left: 30px" class="btn btn-warning" >View Ordered Details</a>
               </div>
    <br>             
</div>
<?php include 'inc/footer.php' ;



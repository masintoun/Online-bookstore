<?php include 'inc/header.php' ?>
<div class="container-12">
    <div class="card card-info">
                <div class="card-title" >
                          
                    <div class="text-center" style="font-size: 20px">Robert Kiyosaki</div>
                </div>        
                <div class="card-body">          
        <div class="row">
             <?php
            $getCanon = $pd->getlatestfromRobert_Kiyosaki();
            if ($getCanon){
                while ($result = $getCanon->fetch_assoc()){
                    ?>
            <div class="col-md-3">
                 <div class="card">
                            <a class="text-center" href="details.php?proId=<?php echo $result['productId']; ?>"><img class="rounded" src="admin/<?php echo $result['image'] ?>" height="180px" max-width="100%" alt="Card image" style=""/></a>
                            <div class="card-body" style="text-align: center;">
                                <div class="card-title" style="font-weight: bold;"><?php echo $result['productName']; ?></div>
                                <div class="card-text"><p>$<?php echo $result['price']; ?></p></div>
                            </div>
                 </div>
            </div>
            <?php } }?>
                </div>
            </div>
         <div class="card-title">                          
             <div class="text-center" style="font-size: 20px">Simon Sinek</div>             
                </div>        
                <div class="card-body">          
        <div class="row">
             <?php
            $getSamsung = $pd->getlatestfromSimon_Sinek();
            if ($getSamsung) {
                while ($result = $getSamsung->fetch_assoc()) {
                    ?>
            <div class="col-md-3">
                 <div class="card">
                            <a class="text-center" href="details.php?proId=<?php echo $result['productId']; ?>"><img class="rounded" src="admin/<?php echo $result['image'] ?>" height="180px" max-width="100%" alt="Card image" style=""/></a>
                            <div class="card-body" style="text-align: center;">
                                <div class="card-title" style="font-weight: bold;"><?php echo $result['productName']; ?></div>
                                <div class="card-text"><p>$<?php echo $result['price']; ?></p></div>
                            </div>
                 </div>
            </div>
            <?php } }?>
                </div>
                    
            </div>
          <div class="card-title">                          
             <div class="text-center" style="font-size: 20px">Rhonda Byrne</div>             
                </div>        
                <div class="card-body">          
        <div class="row">
              <?php
            $getIphone = $pd->getlatestfromRhonda_Byrne();
            if ($getIphone) {
                while ($result = $getIphone->fetch_assoc()) {
                    ?>
            <div class="col-md-3">
                 <div class="card">
                            <a class="text-center" href="details.php?proId=<?php echo $result['productId']; ?>"><img class="rounded" src="admin/<?php echo $result['image'] ?>" height="180px" max-width="100%" alt="Card image" style=""/></a>
                            <div class="card-body" style="text-align: center;">
                                <div class="card-title" style="font-weight: bold;"><?php echo $result['productName']; ?></div>
                                <div class="card-text"><p>$<?php echo $result['price']; ?></p></div>
                            </div>
                 </div>
            </div>
            <?php } }?>
                </div>
                    
            </div>
        <div class="card-title">                          
             <div class="text-center" style="font-size: 20px">Robert Greene</div>             
                </div>        
                <div class="card-body">          
        <div class="row">
              <?php
            $getAcer = $pd->getlatestfromRobert_Greene();
            if ($getAcer) {
                while ($result = $getAcer->fetch_assoc()) {
                    ?>
            <div class="col-md-3">
                 <div class="card">
                            <a class="text-center" href="details.php?proId=<?php echo $result['productId']; ?>"><img class="rounded" src="admin/<?php echo $result['image'] ?>" height="180px" max-width="100%" alt="Card image" style=""/></a>
                            <div class="card-body" style="text-align: center;">
                                <div class="card-title" style="font-weight: bold;"><?php echo $result['productName']; ?></div>
                                <div class="card-text"><p>$<?php echo $result['price']; ?></p></div>

                            </div>
                 </div>
            </div>
            <?php } }?>
                </div>
                    
            </div>
        <div class="card-title">                          
             <div class="text-center" style="font-size: 20px">Thomas J. Stanley</div>             
                </div>        
                <div class="card-body">          
        <div class="row">
              <?php
            $getAcer = $pd->getlatestfromThomas_J_Stanley();
            if ($getAcer) {
                while ($result = $getAcer->fetch_assoc()) {
                    ?>
            <div class="col-md-3">
                 <div class="card">
                            <a class="text-center" href="details.php?proId=<?php echo $result['productId']; ?>"><img class="rounded" src="admin/<?php echo $result['image'] ?>" height="180px" max-width="100%" alt="Card image" style=""/></a>
                            <div class="card-body" style="text-align: center;">
                                <div class="card-title" style="font-weight: bold;"><?php echo $result['productName']; ?></div>
                                <div class="card-text"><p>$<?php echo $result['price']; ?></p></div>
                            </div>
                 </div>
            </div>
            <?php } }?>
                </div>
                    
            </div>
           
        </div>
</div>
<?php include 'inc/footer.php' ?>
